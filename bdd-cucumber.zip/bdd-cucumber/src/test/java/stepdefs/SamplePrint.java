package stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class SamplePrint {

    @Given("^the step one without variables$")
    public void test() {
System.out.println("Step1");
    }

    @Then("^the step two with number variables (\\d+)$")
    public void test1(Integer val) {
        System.out.println(val);
    }

    @Then("^the step two with string variables \"([^\"]*)\"$")
    public void test2(String val) {
        System.out.println(val);
    }
}
