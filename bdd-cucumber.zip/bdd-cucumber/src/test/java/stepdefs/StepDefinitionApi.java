package stepdefs;
import java.util.List;
import java.util.Map;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
public class StepDefinitionApi {
    public static class Steps {
        private static final String USER_ID = "a8cbca7f-0561-41a4-9fdb-2331ff2caf5c";
        private static final String USERNAME = "Testuser1for2021";
        private static final String PASSWORD = "Test@@123";
        private static final String BASE_URL = "https://bookstore.toolsqa.com";

        private static String token;
        private static Response response;
        private static String jsonString;
        private static String bookId;


        @Given("^I am an authorized user$")
        public void iAmAnAuthorizedUser() {

            RestAssured.baseURI = BASE_URL;
            RequestSpecification request = RestAssured.given();

            request.header("Content-Type", "application/json");
            response = request.body("{ \"userName\":\"" + USERNAME + "\", \"password\":\"" + PASSWORD + "\"}")
                    .post("/Account/v1/GenerateToken");

            String jsonString = response.asString();
            token = JsonPath.from(jsonString).get("token");
            System.out.println("Token is --->"+token);

        }

        @Given("^A list of books are available$")
        public void listOfBooksAreAvailable() {
            RestAssured.baseURI = BASE_URL;
            RequestSpecification request = RestAssured.given();
            response = request.get("/BookStore/v1/Books");

            jsonString = response.asString();
            List<Map<String, String>> books = JsonPath.from(jsonString).get("books");
            Assert.assertTrue(books.size() > 0);
            bookId = books.get(0).get("isbn");
            System.out.println("Book id---->"+bookId);
        }

        @When("^I add a book to my reading list$")
        public void addBookInList() {
            RestAssured.baseURI = BASE_URL;
            RequestSpecification request = RestAssured.given();
            request.header("Authorization", "Bearer " + token)
                    .header("Content-Type", "application/json");

            response = request.body("{ \"userId\": \"" + USER_ID + "\", " +
                            "\"collectionOfIsbns\": [ { \"isbn\": \"" + bookId + "\" } ]}")
                    .post("/BookStore/v1/Books");
        }

        @Then("^the book is added$")
        public void bookIsAdded() {
            Assert.assertEquals(201, response.getStatusCode());
        }

        @When("I remove a book from my reading list")
        public void removeBookFromList() {
            RestAssured.baseURI = BASE_URL;
            RequestSpecification request = RestAssured.given();

            request.header("Authorization", "Bearer " + token)
                    .header("Content-Type", "application/json");

            response = request.body("{ \"isbn\": \"" + bookId + "\", \"userId\": \"" + USER_ID + "\"}")
                    .delete("/BookStore/v1/Book");


        }

        @Then("^the book is removed$")
        public void bookIsRemoved() {
            Assert.assertEquals(204, response.getStatusCode());

            RestAssured.baseURI = BASE_URL;
            RequestSpecification request = RestAssured.given();

            request.header("Authorization", "Bearer " + token)
                    .header("Content-Type", "application/json");

            response = request.get("/Account/v1/User/" + USER_ID);
            Assert.assertEquals(200, response.getStatusCode());

            jsonString = response.asString();
            List<Map<String, String>> booksOfUser = JsonPath.from(jsonString).get("books");
            Assert.assertEquals(0, booksOfUser.size());
        }
    }
}
